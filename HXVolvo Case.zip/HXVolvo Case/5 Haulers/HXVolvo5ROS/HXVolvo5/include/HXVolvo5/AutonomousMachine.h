#include <ros/ros.h>
#include <HXVolvo5/askClosestAutonomousMachine.h>
#include <HXVolvo5/selectLPorWL.h>
#include <HXVolvo5/act.h>
#include <HXVolvo5/initAutonomousMachine.h>
#include <HXVolvo5/closestAutonomousMachine.h>
#include <HXVolvo5/askYourPositionAtTime.h>
#include <HXVolvo5/selectNextTask.h>
#include <HXVolvo5/myNextPosition.h>
#include <HXVolvo5/reachLPDestination.h>
#include <HXVolvo5/simulatorTopic.h>
#include <string>
#include <stdlib.h> // sleep function
#include <bitset>
#include <geometry_msgs/Twist.h> // for ROS movement commands 
typedef std::bitset<8> byte;

class AutonomousMachine{
public:
AutonomousMachine(int ID, int initX, int initY, int originTaskInit, int destinationTaskInit, int pathIndexInit, std::string _sender);
void initAutonomousMachineCallback(const HXVolvo5::initAutonomousMachine & thisMsg);
void closestAutonomousMachineCallback(const HXVolvo5::closestAutonomousMachine & thisMsg);
void askYourPositionAtTimeCallback(const HXVolvo5::askYourPositionAtTime & thisMsg);
void selectNextTaskCallback(const HXVolvo5::selectNextTask & thisMsg);
void myNextPositionCallback(const HXVolvo5::myNextPosition & thisMsg);
void reachLPDestinationCallback(const HXVolvo5::reachLPDestination & thisMsg);
private:
int checkGivenPosition(int x1,int y1,int x2,int y2);
int getTimeForMoving(int originTaskPar,int destinationTaskPar,int pathIndexPar);
int getTaskIndex(int destinationTaskPar);
int getPathNum(int originTaskPar,int destinationTaskPar);
/*ROS Fields*/
ros::NodeHandle n;
ros::Publisher simulator_simulatorTopic_pub;
ros::Publisher self_initAutonomousMachine_pub;
ros::Publisher am4_askYourPositionAtTime_pub;
ros::Publisher environment_askClosestAutonomousMachine_pub;
ros::Publisher environment_act_pub;
ros::Publisher am2_myNextPosition_pub;
ros::Publisher am0_askYourPositionAtTime_pub;
ros::Publisher am1_askYourPositionAtTime_pub;
ros::Publisher am3_askYourPositionAtTime_pub;
ros::Publisher am0_myNextPosition_pub;
ros::Publisher am1_myNextPosition_pub;
ros::Publisher am4_myNextPosition_pub;
ros::Publisher environment_selectLPorWL_pub;
ros::Publisher self_selectNextTask_pub;
ros::Publisher am3_myNextPosition_pub;
ros::Publisher am2_askYourPositionAtTime_pub;
ros::Subscriber initAutonomousMachine_sub;
ros::Subscriber closestAutonomousMachine_sub;
ros::Subscriber askYourPositionAtTime_sub;
ros::Subscriber selectNextTask_sub;
ros::Subscriber myNextPosition_sub;
ros::Subscriber reachLPDestination_sub;
/* Reactive Class State Variables as Private Fields */
int id;;
int currentPos[2];;
int otherAuthMachines[5];;
int batteryLevel;;
int originTask;;
int destinationTask;;
int pathIndex;;
std::string sender;
const int numOfMachine = 5;;
const int chargeAmount = 29;;
const int chargeBatteryPerUnit = 10000;;
const int comTime = 500;;
const int waitingTime = 60000;;
const int distanceLimit = 2;;
const int xBound = 10;;
const int yBound = 10;;
const int taskNumber[4][4] = {{- 1,1,3,5},{0,- 1,- 1,7},{2,- 1,- 1,9},{4,6,8,- 1}};;
const int pathCoordinate[10][16][2] = {{{1,6},{2,6},{3,6},{4,6},{5,6},{6,5},{6,4},{6,3},{6,2},{6,1},{6,0},{5,0},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{4,1},{4,2},{4,3},{4,4},{4,5},{3,5},{2,5},{1,5},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{3,8},{4,8},{5,8},{5,7},{5,6},{5,5},{5,4},{5,3},{5,2},{5,1},{5,0},{4,0},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{4,1},{4,2},{4,3},{4,4},{4,5},{4,6},{4,7},{3,7},{2,7},{2,8},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{8,0},{7,0},{6,0},{5,0},{4,0},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{4,1},{5,1},{6,1},{7,1},{8,1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{8,2},{7,2},{6,2},{6,3},{5,3},{4,3},{4,4},{4,5},{3,5},{2,5},{1,5},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{1,6},{2,6},{3,6},{4,6},{5,6},{5,5},{5,4},{5,3},{5,2},{5,1},{6,1},{7,1},{8,1},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{8,2},{7,2},{6,2},{6,3},{5,3},{4,3},{4,4},{4,5},{4,6},{4,7},{3,7},{2,7},{2,8},{- 1,- 1},{- 1,- 1},{- 1,- 1}},{{3,8},{4,8},{5,8},{5,7},{5,6},{5,5},{5,4},{5,3},{5,2},{5,1},{6,1},{7,1},{8,1},{- 1,- 1},{- 1,- 1},{- 1,- 1}}};;
const int pathsTimes[10][16] = {{61156,60151,58984,62168,63041,78305,74334,75481,73310,73054,72610,60310,200000,- 1,- 1,- 1},{46084,45098,47640,43024,41640,60994,62064,58301,150000,- 1,- 1,- 1,- 1,- 1,- 1,- 1},{63640,58060,58604,73030,75002,78344,79050,74305,75054,72054,76045,66054,200000,- 1,- 1,- 1},{47304,45054,43045,45021,48021,55033,47015,63481,60021,44615,150000,- 1,- 1,- 1,- 1,- 1},{79481,62084,60004,61004,62064,200000,- 1,- 1,- 1,- 1,- 1,- 1,- 1,- 1,- 1,- 1},{47651,63054,61213,58518,58084,100000,- 1,- 1,- 1,- 1,- 1,- 1,- 1,- 1,- 1,- 1},{48312,60048,61048,44984,61078,62648,44015,48548,61648,60054,62551,150000,- 1,- 1,- 1,- 1},{44840,62084,61989,62618,59098,73335,73989,76998,75021,75322,62048,59848,61660,100000,- 1,- 1},{44018,61616,61118,44688,62081,63118,46787,45777,45985,42452,61004,60848,48884,150000,- 1,- 1},{62335,62554,59454,63115,63665,61448,60488,60088,59988,59048,62464,62684,60887,100000,- 1,- 1}};;
};