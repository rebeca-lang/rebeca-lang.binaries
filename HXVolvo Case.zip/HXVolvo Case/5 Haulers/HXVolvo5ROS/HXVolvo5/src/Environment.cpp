#include <HXVolvo5/Environment.h>


/* the following variables are needed for using sender keyword */
std::string am0;
std::string am1;
std::string am2;
std::string am3;
std::string am4;
int main(int argc, char** argv){
	ROS_INFO("Environment node started");
	ros::init(argc, argv, "Environment_node");
	ros::NodeHandle nh("~");
	std::string sender;
	 nh.getParam("sender", sender);
	 nh.getParam("am0", am0);
	 nh.getParam("am1", am1);
	 nh.getParam("am2", am2);
	 nh.getParam("am3", am3);
	 nh.getParam("am4", am4);
	int am0X;
	 nh.getParam("am0X", am0X);
	int am0Y;
	 nh.getParam("am0Y", am0Y);
	int am1X;
	 nh.getParam("am1X", am1X);
	int am1Y;
	 nh.getParam("am1Y", am1Y);
	int am2X;
	 nh.getParam("am2X", am2X);
	int am2Y;
	 nh.getParam("am2Y", am2Y);
	int am3X;
	 nh.getParam("am3X", am3X);
	int am3Y;
	 nh.getParam("am3Y", am3Y);
	int am4X;
	 nh.getParam("am4X", am4X);
	int am4Y;
	 nh.getParam("am4Y", am4Y);
	Environment _environment(am0X, am0Y, am1X, am1Y, am2X, am2Y, am3X, am3Y, am4X, am4Y, sender);
}


Environment::Environment(int am0X, int am0Y, int am1X, int am1Y, int am2X, int am2Y, int am3X, int am3Y, int am4X, int am4Y, std::string _sender){
askClosestAutonomousMachine_sub = n.subscribe("Environment/askClosestAutonomousMachine", 30, &Environment::askClosestAutonomousMachineCallback, this);
selectLPorWL_sub = n.subscribe("Environment/selectLPorWL", 30, &Environment::selectLPorWLCallback, this);
act_sub = n.subscribe("Environment/act", 30, &Environment::actCallback, this);
am4_closestAutonomousMachine_pub = n.advertise<HXVolvo5::closestAutonomousMachine>("am4/closestAutonomousMachine", 30);
am0_reachLPDestination_pub = n.advertise<HXVolvo5::reachLPDestination>("am0/reachLPDestination", 30);
am3_reachLPDestination_pub = n.advertise<HXVolvo5::reachLPDestination>("am3/reachLPDestination", 30);
am1_closestAutonomousMachine_pub = n.advertise<HXVolvo5::closestAutonomousMachine>("am1/closestAutonomousMachine", 30);
am1_reachLPDestination_pub = n.advertise<HXVolvo5::reachLPDestination>("am1/reachLPDestination", 30);
am0_closestAutonomousMachine_pub = n.advertise<HXVolvo5::closestAutonomousMachine>("am0/closestAutonomousMachine", 30);
am2_closestAutonomousMachine_pub = n.advertise<HXVolvo5::closestAutonomousMachine>("am2/closestAutonomousMachine", 30);
am4_reachLPDestination_pub = n.advertise<HXVolvo5::reachLPDestination>("am4/reachLPDestination", 30);
am3_closestAutonomousMachine_pub = n.advertise<HXVolvo5::closestAutonomousMachine>("am3/closestAutonomousMachine", 30);
am2_reachLPDestination_pub = n.advertise<HXVolvo5::reachLPDestination>("am2/reachLPDestination", 30);
sender = _sender;
while(am4_closestAutonomousMachine_pub.getNumSubscribers() < 1 ||am0_reachLPDestination_pub.getNumSubscribers() < 1 ||am3_reachLPDestination_pub.getNumSubscribers() < 1 ||am1_closestAutonomousMachine_pub.getNumSubscribers() < 1 ||am1_reachLPDestination_pub.getNumSubscribers() < 1 ||am0_closestAutonomousMachine_pub.getNumSubscribers() < 1 ||am2_closestAutonomousMachine_pub.getNumSubscribers() < 1 ||am4_reachLPDestination_pub.getNumSubscribers() < 1 ||am3_closestAutonomousMachine_pub.getNumSubscribers() < 1 ||am2_reachLPDestination_pub.getNumSubscribers() < 1 );
amPositions[0][0] = am0X;
amPositions[0][1] = am0Y;
amPositions[1][0] = am1X;
amPositions[1][1] = am1Y;
amPositions[2][0] = am2X;
amPositions[2][1] = am2Y;
amPositions[3][0] = am3X;
amPositions[3][1] = am3Y;
amPositions[4][0] = am4X;
amPositions[4][1] = am4Y;

ros::spin();
}

void Environment::askClosestAutonomousMachineCallback(const HXVolvo5::askClosestAutonomousMachine & thisMsg){
int amID;;
if (thisMsg.sender == am0) {amID = 0;}
else {
if (thisMsg.sender == am1) {amID = 1;}
else {
if (thisMsg.sender == am2) {amID = 2;}
else {
if (thisMsg.sender == am3) {amID = 3;}
else {
if (thisMsg.sender == am4) {amID = 4;};};};};};
bool cAM[5];;
cAM[amID] = false;
for(int i = 0;i < numOfMachine; i++){
if (i != amID) {cAM[i] = isAutonomousMachineCloseEnough(amPositions[amID][0],amPositions[amID][1],amPositions[i][0],amPositions[i][1]);};}
;
switch(amID){
case 0 : {
HXVolvo5::closestAutonomousMachine pubMsg1920;
pubMsg1920.autMach0 = cAM[0];
pubMsg1920.autMach1 = cAM[1];
pubMsg1920.autMach2 = cAM[2];
pubMsg1920.autMach3 = cAM[3];
pubMsg1920.autMach4 = cAM[4];
pubMsg1920.sender=sender;
am0_closestAutonomousMachine_pub.publish(pubMsg1920);
; break;; }
case 1 : {
HXVolvo5::closestAutonomousMachine pubMsg1921;
pubMsg1921.autMach0 = cAM[0];
pubMsg1921.autMach1 = cAM[1];
pubMsg1921.autMach2 = cAM[2];
pubMsg1921.autMach3 = cAM[3];
pubMsg1921.autMach4 = cAM[4];
pubMsg1921.sender=sender;
am1_closestAutonomousMachine_pub.publish(pubMsg1921);
; break;; }
case 2 : {
HXVolvo5::closestAutonomousMachine pubMsg1922;
pubMsg1922.autMach0 = cAM[0];
pubMsg1922.autMach1 = cAM[1];
pubMsg1922.autMach2 = cAM[2];
pubMsg1922.autMach3 = cAM[3];
pubMsg1922.autMach4 = cAM[4];
pubMsg1922.sender=sender;
am2_closestAutonomousMachine_pub.publish(pubMsg1922);
; break;; }
case 3 : {
HXVolvo5::closestAutonomousMachine pubMsg1923;
pubMsg1923.autMach0 = cAM[0];
pubMsg1923.autMach1 = cAM[1];
pubMsg1923.autMach2 = cAM[2];
pubMsg1923.autMach3 = cAM[3];
pubMsg1923.autMach4 = cAM[4];
pubMsg1923.sender=sender;
am3_closestAutonomousMachine_pub.publish(pubMsg1923);
; break;; }
case 4 : {
HXVolvo5::closestAutonomousMachine pubMsg1924;
pubMsg1924.autMach0 = cAM[0];
pubMsg1924.autMach1 = cAM[1];
pubMsg1924.autMach2 = cAM[2];
pubMsg1924.autMach3 = cAM[3];
pubMsg1924.autMach4 = cAM[4];
pubMsg1924.sender=sender;
am4_closestAutonomousMachine_pub.publish(pubMsg1924);
; break;; }
}
;

}

void Environment::selectLPorWLCallback(const HXVolvo5::selectLPorWL & thisMsg){
int queueLP = 0;;
int queueWL = 0;;
for(int i = 0;i < numOfMachine; i++){
if (amPositions[i][0] == 3 && amPositions[i][1] == 5 || amPositions[i][0] == 2 && amPositions[i][1] == 5) {queueLP++;};}
;
for(int i = 0;i < numOfMachine; i++){
if (amPositions[i][0] == 4 && amPositions[i][1] == 6 || amPositions[i][0] == 4 && amPositions[i][1] == 7 || amPositions[i][0] == 3 && amPositions[i][1] == 7 || amPositions[i][0] == 2 && amPositions[i][1] == 7 || amPositions[i][0] == 2 && amPositions[i][1] == 8) {queueWL++;};}
;
bool isLPBetter = queueLP <= queueWL;;
if (thisMsg.sender == am0) {HXVolvo5::reachLPDestination pubMsg1925;
pubMsg1925.isLPBetter = isLPBetter;
pubMsg1925.sender=sender;
am0_reachLPDestination_pub.publish(pubMsg1925);
;}
else {
if (thisMsg.sender == am1) {HXVolvo5::reachLPDestination pubMsg1926;
pubMsg1926.isLPBetter = isLPBetter;
pubMsg1926.sender=sender;
am1_reachLPDestination_pub.publish(pubMsg1926);
;}
else {
if (thisMsg.sender == am2) {HXVolvo5::reachLPDestination pubMsg1927;
pubMsg1927.isLPBetter = isLPBetter;
pubMsg1927.sender=sender;
am2_reachLPDestination_pub.publish(pubMsg1927);
;}
else {
if (thisMsg.sender == am3) {HXVolvo5::reachLPDestination pubMsg1928;
pubMsg1928.isLPBetter = isLPBetter;
pubMsg1928.sender=sender;
am3_reachLPDestination_pub.publish(pubMsg1928);
;}
else {
if (thisMsg.sender == am4) {HXVolvo5::reachLPDestination pubMsg1929;
pubMsg1929.isLPBetter = isLPBetter;
pubMsg1929.sender=sender;
am4_reachLPDestination_pub.publish(pubMsg1929);
;};};};};};

}

void Environment::actCallback(const HXVolvo5::act & thisMsg){
#define currX thisMsg.currX
#define currY thisMsg.currY
int amID;;
if (thisMsg.sender == am0) {amID = 0;}
else {
if (thisMsg.sender == am1) {amID = 1;}
else {
if (thisMsg.sender == am2) {amID = 2;}
else {
if (thisMsg.sender == am3) {amID = 3;}
else {
if (thisMsg.sender == am4) {amID = 4;};};};};};
amPositions[amID][0] = currX;
amPositions[amID][1] = currY;
if (currX < 0 || currX >= xBound || currY < 0 || currY >= yBound) {;};

#undef currX
#undef currY
}

bool Environment::isAutonomousMachineCloseEnough(int x0,int y0,int x1,int y1){
int distance = 0;;
int xDist;int yDist;;
if (x0 >= x1) {xDist = x0 - x1;}
else {
xDist = x1 - x0;};
if (y0 >= y1) {yDist = y0 - y1;}
else {
yDist = y1 - y0;};
distance = xDist + yDist;
if (distance <= distanceLimit) {return true;}
else {
return false;};

}

