#include <HXVolvo5/AutonomousMachine.h>


/* the following variables are needed for using sender keyword */
std::string environment;
std::string am0;
std::string am1;
std::string am2;
std::string am3;
std::string am4;
std::string simulator;
int main(int argc, char** argv){
	ROS_INFO("AutonomousMachine node started");
	ros::init(argc, argv, "AutonomousMachine_node");
	ros::NodeHandle nh("~");
	std::string sender;
	 nh.getParam("sender", sender);
	 nh.getParam("environment", environment);
	 nh.getParam("am0", am0);
	 nh.getParam("am1", am1);
	 nh.getParam("am2", am2);
	 nh.getParam("am3", am3);
	 nh.getParam("am4", am4);
	 nh.getParam("simulator", simulator);
	int ID;
	 nh.getParam("ID", ID);
	int initX;
	 nh.getParam("initX", initX);
	int initY;
	 nh.getParam("initY", initY);
	int originTaskInit;
	 nh.getParam("originTaskInit", originTaskInit);
	int destinationTaskInit;
	 nh.getParam("destinationTaskInit", destinationTaskInit);
	int pathIndexInit;
	 nh.getParam("pathIndexInit", pathIndexInit);
	AutonomousMachine _autonomousmachine(ID, initX, initY, originTaskInit, destinationTaskInit, pathIndexInit, sender);
}


AutonomousMachine::AutonomousMachine(int ID, int initX, int initY, int originTaskInit, int destinationTaskInit, int pathIndexInit, std::string _sender){
initAutonomousMachine_sub = n.subscribe("AutonomousMachine/initAutonomousMachine", 30, &AutonomousMachine::initAutonomousMachineCallback, this);
closestAutonomousMachine_sub = n.subscribe("AutonomousMachine/closestAutonomousMachine", 30, &AutonomousMachine::closestAutonomousMachineCallback, this);
askYourPositionAtTime_sub = n.subscribe("AutonomousMachine/askYourPositionAtTime", 30, &AutonomousMachine::askYourPositionAtTimeCallback, this);
selectNextTask_sub = n.subscribe("AutonomousMachine/selectNextTask", 30, &AutonomousMachine::selectNextTaskCallback, this);
myNextPosition_sub = n.subscribe("AutonomousMachine/myNextPosition", 30, &AutonomousMachine::myNextPositionCallback, this);
reachLPDestination_sub = n.subscribe("AutonomousMachine/reachLPDestination", 30, &AutonomousMachine::reachLPDestinationCallback, this);
simulator_simulatorTopic_pub = n.advertise<HXVolvo5::simulatorTopic>("simulator/simulatorTopic", 30);
self_initAutonomousMachine_pub = n.advertise<HXVolvo5::initAutonomousMachine>("AutonomousMachine/initAutonomousMachine", 30);
am4_askYourPositionAtTime_pub = n.advertise<HXVolvo5::askYourPositionAtTime>("am4/askYourPositionAtTime", 30);
environment_askClosestAutonomousMachine_pub = n.advertise<HXVolvo5::askClosestAutonomousMachine>("environment/askClosestAutonomousMachine", 30);
environment_act_pub = n.advertise<HXVolvo5::act>("environment/act", 30);
am2_myNextPosition_pub = n.advertise<HXVolvo5::myNextPosition>("am2/myNextPosition", 30);
am0_askYourPositionAtTime_pub = n.advertise<HXVolvo5::askYourPositionAtTime>("am0/askYourPositionAtTime", 30);
am1_askYourPositionAtTime_pub = n.advertise<HXVolvo5::askYourPositionAtTime>("am1/askYourPositionAtTime", 30);
am3_askYourPositionAtTime_pub = n.advertise<HXVolvo5::askYourPositionAtTime>("am3/askYourPositionAtTime", 30);
am0_myNextPosition_pub = n.advertise<HXVolvo5::myNextPosition>("am0/myNextPosition", 30);
am1_myNextPosition_pub = n.advertise<HXVolvo5::myNextPosition>("am1/myNextPosition", 30);
am4_myNextPosition_pub = n.advertise<HXVolvo5::myNextPosition>("am4/myNextPosition", 30);
environment_selectLPorWL_pub = n.advertise<HXVolvo5::selectLPorWL>("environment/selectLPorWL", 30);
self_selectNextTask_pub = n.advertise<HXVolvo5::selectNextTask>("AutonomousMachine/selectNextTask", 30);
am3_myNextPosition_pub = n.advertise<HXVolvo5::myNextPosition>("am3/myNextPosition", 30);
am2_askYourPositionAtTime_pub = n.advertise<HXVolvo5::askYourPositionAtTime>("am2/askYourPositionAtTime", 30);
sender = _sender;
while(simulator_simulatorTopic_pub.getNumSubscribers() < 1 ||self_initAutonomousMachine_pub.getNumSubscribers() < 1 ||am4_askYourPositionAtTime_pub.getNumSubscribers() < 1 ||environment_askClosestAutonomousMachine_pub.getNumSubscribers() < 1 ||environment_act_pub.getNumSubscribers() < 1 ||am2_myNextPosition_pub.getNumSubscribers() < 1 ||am0_askYourPositionAtTime_pub.getNumSubscribers() < 1 ||am1_askYourPositionAtTime_pub.getNumSubscribers() < 1 ||am3_askYourPositionAtTime_pub.getNumSubscribers() < 1 ||am0_myNextPosition_pub.getNumSubscribers() < 1 ||am1_myNextPosition_pub.getNumSubscribers() < 1 ||am4_myNextPosition_pub.getNumSubscribers() < 1 ||environment_selectLPorWL_pub.getNumSubscribers() < 1 ||self_selectNextTask_pub.getNumSubscribers() < 1 ||am3_myNextPosition_pub.getNumSubscribers() < 1 ||am2_askYourPositionAtTime_pub.getNumSubscribers() < 1 );
id = ID;
currentPos[0] = initX;
currentPos[1] = initY;
originTask = originTaskInit;
destinationTask = destinationTaskInit;
pathIndex = pathIndexInit;
for(int i = 0;i < numOfMachine; i++){
otherAuthMachines[i] = - 1;}
;
batteryLevel = chargeAmount;
otherAuthMachines[id] = 0;
otherAuthMachines[id] = 0;
HXVolvo5::initAutonomousMachine pubMsg1953;
pubMsg1953.sender=sender;
self_initAutonomousMachine_pub.publish(pubMsg1953);
;

ros::spin();
}

void AutonomousMachine::initAutonomousMachineCallback(const HXVolvo5::initAutonomousMachine & thisMsg){
sleep(1);
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
HXVolvo5::askClosestAutonomousMachine pubMsg1954;
pubMsg1954.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg1954);
;

}

void AutonomousMachine::closestAutonomousMachineCallback(const HXVolvo5::closestAutonomousMachine & thisMsg){
#define autMach0 thisMsg.autMach0
#define autMach1 thisMsg.autMach1
#define autMach2 thisMsg.autMach2
#define autMach3 thisMsg.autMach3
#define autMach4 thisMsg.autMach4
int pathNum = getPathNum(originTask,destinationTask);;
if (autMach0 && id != 0) {HXVolvo5::askYourPositionAtTime pubMsg1955;
pubMsg1955.sender=sender;
am0_askYourPositionAtTime_pub.publish(pubMsg1955);
;}
else {
if (id != 0) {otherAuthMachines[0] = 0;};};
if (autMach1 && id != 1) {HXVolvo5::askYourPositionAtTime pubMsg1956;
pubMsg1956.sender=sender;
am1_askYourPositionAtTime_pub.publish(pubMsg1956);
;}
else {
if (id != 1) {otherAuthMachines[1] = 0;};};
if (autMach2 && id != 2) {HXVolvo5::askYourPositionAtTime pubMsg1957;
pubMsg1957.sender=sender;
am2_askYourPositionAtTime_pub.publish(pubMsg1957);
;}
else {
if (id != 2) {otherAuthMachines[2] = 0;};};
if (autMach3 && id != 3) {HXVolvo5::askYourPositionAtTime pubMsg1958;
pubMsg1958.sender=sender;
am3_askYourPositionAtTime_pub.publish(pubMsg1958);
;}
else {
if (id != 3) {otherAuthMachines[3] = 0;};};
if (autMach4 && id != 4) {HXVolvo5::askYourPositionAtTime pubMsg1959;
pubMsg1959.sender=sender;
am4_askYourPositionAtTime_pub.publish(pubMsg1959);
;}
else {
if (id != 4) {otherAuthMachines[4] = 0;};};
sleep(1);
if (! autMach0 && ! autMach1 && ! autMach2 && ! autMach3 && ! autMach4) {HXVolvo5::simulatorTopic pubMsg1960;
pubMsg1960.robotId = id;
pubMsg1960.pathNum = pathNum;
pubMsg1960.pathIndex = pathIndex;
pubMsg1960.sender=sender;
simulator_simulatorTopic_pub.publish(pubMsg1960);
;
batteryLevel--;
currentPos[0] = pathCoordinate[pathNum][pathIndex][0];
currentPos[1] = pathCoordinate[pathNum][pathIndex][1];
pathIndex++;
HXVolvo5::act pubMsg1961;
pubMsg1961.currX = currentPos[0];
pubMsg1961.currY = currentPos[1];
pubMsg1961.sender=sender;
environment_act_pub.publish(pubMsg1961);
;
sleep(1);
if (batteryLevel <= 0) {;};
for(int i = 0;i < numOfMachine; i++){
otherAuthMachines[i] = - 1;}
;
bool isNotAtIntersection = true;;
if (currentPos[0] == 4 && currentPos[1] == 5 && destinationTask == 1 || destinationTask == 2) {HXVolvo5::selectLPorWL pubMsg1962;
pubMsg1962.sender=sender;
environment_selectLPorWL_pub.publish(pubMsg1962);
;}
else {
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
int newX = pathCoordinate[pathNum][pathIndex][0];;
int newY = pathCoordinate[pathNum][pathIndex][1];;
if (newX != - 1 && newY != - 1) {otherAuthMachines[id] = 0;
HXVolvo5::askClosestAutonomousMachine pubMsg1963;
pubMsg1963.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg1963);
;

;}
else {
if (destinationTask == 0) {timeForMoving = chargeAmount - batteryLevel * chargeBatteryPerUnit + comTime;};
HXVolvo5::selectNextTask pubMsg1964;
pubMsg1964.sender=sender;
self_selectNextTask_pub.publish(pubMsg1964);
;

;};

;};

;};

#undef autMach0
#undef autMach1
#undef autMach2
#undef autMach3
#undef autMach4
}

void AutonomousMachine::askYourPositionAtTimeCallback(const HXVolvo5::askYourPositionAtTime & thisMsg){
sleep(1);
if (thisMsg.sender == am0) {HXVolvo5::myNextPosition pubMsg1965;
pubMsg1965.nextX = currentPos[0];
pubMsg1965.nextY = currentPos[1];
pubMsg1965.sender=sender;
am0_myNextPosition_pub.publish(pubMsg1965);
;}
else {
if (thisMsg.sender == am1) {HXVolvo5::myNextPosition pubMsg1966;
pubMsg1966.nextX = currentPos[0];
pubMsg1966.nextY = currentPos[1];
pubMsg1966.sender=sender;
am1_myNextPosition_pub.publish(pubMsg1966);
;}
else {
if (thisMsg.sender == am2) {HXVolvo5::myNextPosition pubMsg1967;
pubMsg1967.nextX = currentPos[0];
pubMsg1967.nextY = currentPos[1];
pubMsg1967.sender=sender;
am2_myNextPosition_pub.publish(pubMsg1967);
;}
else {
if (thisMsg.sender == am3) {HXVolvo5::myNextPosition pubMsg1968;
pubMsg1968.nextX = currentPos[0];
pubMsg1968.nextY = currentPos[1];
pubMsg1968.sender=sender;
am3_myNextPosition_pub.publish(pubMsg1968);
;}
else {
if (thisMsg.sender == am4) {HXVolvo5::myNextPosition pubMsg1969;
pubMsg1969.nextX = currentPos[0];
pubMsg1969.nextY = currentPos[1];
pubMsg1969.sender=sender;
am4_myNextPosition_pub.publish(pubMsg1969);
;};};};};};

}

void AutonomousMachine::selectNextTaskCallback(const HXVolvo5::selectNextTask & thisMsg){
originTask = destinationTask;
if (destinationTask == 0) {batteryLevel = chargeAmount;};
pathIndex = 0;
int taskIndex = getTaskIndex(destinationTask);;
switch(taskIndex){
case 0 : {
destinationTask = 3; break;; }
case 1 : {
destinationTask = 0; break;; }
case 2 : {
destinationTask = 1; break;; }
}
;
int pathNum = getPathNum(originTask,destinationTask);;
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
otherAuthMachines[id] = 0;
HXVolvo5::askClosestAutonomousMachine pubMsg1970;
pubMsg1970.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg1970);
;

}

void AutonomousMachine::myNextPositionCallback(const HXVolvo5::myNextPosition & thisMsg){
#define nextX thisMsg.nextX
#define nextY thisMsg.nextY
int pathNum = getPathNum(originTask,destinationTask);;
int myNextX = pathCoordinate[pathNum][pathIndex][0];;
int myNextY = pathCoordinate[pathNum][pathIndex][1];;
sleep(1);
if (currentPos[0] == nextX && currentPos[1] == nextY) {;};
int machineId;;
if (thisMsg.sender == am0) {machineId = 0;}
else {
if (thisMsg.sender == am1) {machineId = 1;}
else {
if (thisMsg.sender == am2) {machineId = 2;}
else {
if (thisMsg.sender == am3) {machineId = 3;}
else {
if (thisMsg.sender == am4) {machineId = 4;};};};};};
otherAuthMachines[machineId] = checkGivenPosition(myNextX,myNextY,nextX,nextY);
bool isWaiting = false;;
bool allHaulers = false;;
for(int i = 0;i < numOfMachine; i++){
if (otherAuthMachines[i] == - 1) {allHaulers = false;

;}
else {
allHaulers = true;};}
;
if (allHaulers) {for(int i = 0;i < numOfMachine; i++){
if (i != id) {if (otherAuthMachines[i] == 1) {isWaiting = true;
break;;

;};};}
;
batteryLevel--;
if (! isWaiting) {currentPos[0] = myNextX;
currentPos[1] = myNextY;
pathIndex++;

;};
HXVolvo5::act pubMsg1971;
pubMsg1971.currX = currentPos[0];
pubMsg1971.currY = currentPos[1];
pubMsg1971.sender=sender;
environment_act_pub.publish(pubMsg1971);
;
sleep(1);
if (batteryLevel <= 0) {;};
for(int i = 0;i < numOfMachine; i++){
otherAuthMachines[i] = - 1;}
;
bool isNotAtIntersection = true;;
if (currentPos[0] == 4 && currentPos[1] == 5 && destinationTask == 1 || destinationTask == 2) {HXVolvo5::selectLPorWL pubMsg1972;
pubMsg1972.sender=sender;
environment_selectLPorWL_pub.publish(pubMsg1972);
;}
else {
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
int newX = pathCoordinate[pathNum][pathIndex][0];;
int newY = pathCoordinate[pathNum][pathIndex][1];;
if (newX != - 1 && newY != - 1) {otherAuthMachines[id] = 0;
HXVolvo5::askClosestAutonomousMachine pubMsg1973;
pubMsg1973.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg1973);
;

;}
else {
if (destinationTask == 0) {timeForMoving = chargeAmount - batteryLevel * chargeBatteryPerUnit + comTime;};
HXVolvo5::selectNextTask pubMsg1974;
pubMsg1974.sender=sender;
self_selectNextTask_pub.publish(pubMsg1974);
;

;};

;};

;};

#undef nextX
#undef nextY
}

void AutonomousMachine::reachLPDestinationCallback(const HXVolvo5::reachLPDestination & thisMsg){
#define isLPBetter thisMsg.isLPBetter
destinationTask = (isLPBetter) ? (1) : (2);
int pathNum = (isLPBetter) ? (1) : (3);;
pathIndex = 5;
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
otherAuthMachines[id] = 0;
HXVolvo5::askClosestAutonomousMachine pubMsg1975;
pubMsg1975.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg1975);
;

#undef isLPBetter
}

int AutonomousMachine::checkGivenPosition(int x1,int y1,int x2,int y2){
if (x1 != x2 || y1 != y2) {return 0;}
else {
return 1;};

}

int AutonomousMachine::getTimeForMoving(int originTaskPar,int destinationTaskPar,int pathIndexPar){
int pathNum = getPathNum(originTaskPar,destinationTaskPar);;
return pathsTimes[pathNum][pathIndexPar];

}

int AutonomousMachine::getTaskIndex(int destinationTaskPar){
int taskIndex;;
switch(destinationTaskPar){
case 0 : {
taskIndex = 2; break;; }
case 1 : {
taskIndex = 0; break;; }
case 2 : {
taskIndex = 0; break;; }
case 3 : {
taskIndex = 1; break;; }
}
;
return taskIndex;

}

int AutonomousMachine::getPathNum(int originTaskPar,int destinationTaskPar){
return taskNumber[originTaskPar][destinationTaskPar];

}

