#include <hauler_plugin/hauler_plugin.h>

int main(int argc, char** argv){
	ROS_INFO("plugin started");
	ros::init(argc, argv, "plugin_node");
        HaulerPlugin _hauler_plugin;
}

HaulerPlugin::HaulerPlugin(){
    	am_pub_visualizer1 = n.advertise<geometry_msgs::Twist>("/robot_0/cmd_vel", 30);
        am_pub_visualizer2 = n.advertise<geometry_msgs::Twist>("/robot_1/cmd_vel", 30);
        am_pub_visualizer3 = n.advertise<geometry_msgs::Twist>("/robot_2/cmd_vel", 30);
        am_pub_visualizer4 = n.advertise<geometry_msgs::Twist>("/robot_3/cmd_vel", 30);
        am_pub_visualizer5 = n.advertise<geometry_msgs::Twist>("/robot_4/cmd_vel", 30);

        simulation_sub = n.subscribe("simulator/simulatorTopic", 30, &HaulerPlugin::visualizationCallback, this);
        ROS_INFO("plugin constructor");
        ros::spin();

}

void HaulerPlugin::visualizationCallback(const HXVolvo2::simulatorTopic & thisMsg){
    ROS_INFO("plugin worked");
#define pathNum thisMsg.pathNum
#define pathIndex thisMsg.pathIndex
#define robotId thisMsg.robotId
		
    std::cout << "id:" << robotId << "pathNum:" << pathNum << ", pathIndex:" << pathIndex << std::endl;
		
		geometry_msgs::Twist actionMsg;
        if(robotId == 0){
		/* CS->LP*/
                    if(pathNum == 1){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 8){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                    }
                    /* LP->UP */
                    else if(pathNum == 7){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                    }
                    /* UP->CS */
                    else if(pathNum == 4){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                    }
                    /* CS->WL */
                    else if(pathNum == 3){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 7){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 9){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                    }
                    /* WL->UP */
                    else if(pathNum == 9){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 3){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                            }
                    }
                    
                    actionMsg.angular.z = 0.0;
                    actionMsg.linear.x = 1.0;
                                    
                    am_pub_visualizer1.publish(actionMsg); sleep(1);
                    am_pub_visualizer1.publish(actionMsg); sleep(1);
        }
        
        
        if(robotId == 1){
  		/* CS->LP*/
                    if(pathNum == 1){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 8){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                    }
                    /* LP->UP */
                    else if(pathNum == 7){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                    }
                    /* UP->CS */
                    else if(pathNum == 4){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                    }
                    /* CS->WL */
                    else if(pathNum == 3){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 7){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 9){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                    }
                    /* WL->UP */
                    else if(pathNum == 9){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 3){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                            }
                    }
                    
                    actionMsg.angular.z = 0.0;
                    actionMsg.linear.x = 1.0;
                                    
                    am_pub_visualizer2.publish(actionMsg); sleep(1);
                    am_pub_visualizer2.publish(actionMsg); sleep(1);
        }
          
        if(robotId == 2){
		/* CS->LP*/
                    if(pathNum == 1){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 8){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                    }
                    /* LP->UP */
                    else if(pathNum == 7){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                    }
                    /* UP->CS */
                    else if(pathNum == 4){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                    }
                    /* CS->WL */
                    else if(pathNum == 3){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 7){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 9){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                    }
                    /* WL->UP */
                    else if(pathNum == 9){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 3){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                            }
                    }
                    
                    actionMsg.angular.z = 0.0;
                    actionMsg.linear.x = 1.0;
                                    
                    am_pub_visualizer3.publish(actionMsg); sleep(1);
                    am_pub_visualizer3.publish(actionMsg); sleep(1);
        }
        if(robotId == 3){
		/* CS->LP*/
                    if(pathNum == 1){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 8){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                    }
                    /* LP->UP */
                    else if(pathNum == 7){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                    }
                    /* UP->CS */
                    else if(pathNum == 4){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                    }
                    /* CS->WL */
                    else if(pathNum == 3){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 7){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 9){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                    }
                    /* WL->UP */
                    else if(pathNum == 9){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 3){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                            }
                    }
                    
                    actionMsg.angular.z = 0.0;
                    actionMsg.linear.x = 1.0;
                                    
                    am_pub_visualizer4.publish(actionMsg); sleep(1);
                    am_pub_visualizer4.publish(actionMsg); sleep(1);
        }
        if(robotId == 3){
		/* CS->LP*/
                    if(pathNum == 1){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 8){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                    }
                    /* LP->UP */
                    else if(pathNum == 7){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                    }
                    /* UP->CS */
                    else if(pathNum == 4){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 1){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 5){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                    }
                    /* CS->WL */
                    else if(pathNum == 3){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 7){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 9){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                    }
                    /* WL->UP */
                    else if(pathNum == 9){
                            if (pathIndex == 0){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 3){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 10){
                                    actionMsg.angular.z = -PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                            else if (pathIndex == 13){
                                    actionMsg.angular.z = PI;
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                            }
                    }
                    
                    actionMsg.angular.z = 0.0;
                    actionMsg.linear.x = 1.0;
                                    
                    am_pub_visualizer5.publish(actionMsg); sleep(1);
                    am_pub_visualizer5.publish(actionMsg); sleep(1);
        }
}