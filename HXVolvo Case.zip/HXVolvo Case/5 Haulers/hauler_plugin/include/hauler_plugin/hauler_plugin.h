#include <HXVolvo2/simulatorTopic.h>
#include <ros/ros.h>
#include <geometry_msgs/Twist.h> // for ROS movement commands 
#include <string>
#include <stdlib.h> // sleep function


#define  PI 3.1415926535897

class HaulerPlugin{
public:
    HaulerPlugin();
    void visualizationCallback(const HXVolvo2::simulatorTopic & thisMsg);
    
private:
    ros::NodeHandle n;
    ros::Subscriber simulation_sub;
    ros::Publisher am_pub_visualizer1;
    ros::Publisher am_pub_visualizer2;
    ros::Publisher am_pub_visualizer3;
    ros::Publisher am_pub_visualizer4;
    ros::Publisher am_pub_visualizer5;

    
};