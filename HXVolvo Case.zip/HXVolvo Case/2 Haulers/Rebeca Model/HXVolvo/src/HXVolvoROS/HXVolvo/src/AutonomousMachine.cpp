#include <HXVolvo/AutonomousMachine.h>


/* the following variables are needed for using sender keyword */
std::string environment;
std::string am0;
std::string am1;
std::string simulator;
int main(int argc, char** argv){
	ROS_INFO("AutonomousMachine node started");
	ros::init(argc, argv, "AutonomousMachine_node");
	ros::NodeHandle nh("~");
	std::string sender;
	 nh.getParam("sender", sender);
	 nh.getParam("environment", environment);
	 nh.getParam("am0", am0);
	 nh.getParam("am1", am1);
	 nh.getParam("simulator", simulator);
	int ID;
	 nh.getParam("ID", ID);
	int initX;
	 nh.getParam("initX", initX);
	int initY;
	 nh.getParam("initY", initY);
	int originTaskInit;
	 nh.getParam("originTaskInit", originTaskInit);
	int destinationTaskInit;
	 nh.getParam("destinationTaskInit", destinationTaskInit);
	int pathIndexInit;
	 nh.getParam("pathIndexInit", pathIndexInit);
	AutonomousMachine _autonomousmachine(ID, initX, initY, originTaskInit, destinationTaskInit, pathIndexInit, sender);
}


AutonomousMachine::AutonomousMachine(int ID, int initX, int initY, int originTaskInit, int destinationTaskInit, int pathIndexInit, std::string _sender){
initAutonomousMachine_sub = n.subscribe("AutonomousMachine/initAutonomousMachine", 30, &AutonomousMachine::initAutonomousMachineCallback, this);
closestAutonomousMachine_sub = n.subscribe("AutonomousMachine/closestAutonomousMachine", 30, &AutonomousMachine::closestAutonomousMachineCallback, this);
askYourPositionAtTime_sub = n.subscribe("AutonomousMachine/askYourPositionAtTime", 30, &AutonomousMachine::askYourPositionAtTimeCallback, this);
selectNextTask_sub = n.subscribe("AutonomousMachine/selectNextTask", 30, &AutonomousMachine::selectNextTaskCallback, this);
myNextPosition_sub = n.subscribe("AutonomousMachine/myNextPosition", 30, &AutonomousMachine::myNextPositionCallback, this);
reachLPDestination_sub = n.subscribe("AutonomousMachine/reachLPDestination", 30, &AutonomousMachine::reachLPDestinationCallback, this);
simulator_simulatorTopic_pub = n.advertise<HXVolvo::simulatorTopic>("simulator/simulatorTopic", 30);
am1_myNextPosition_pub = n.advertise<HXVolvo::myNextPosition>("am1/myNextPosition", 30);
self_initAutonomousMachine_pub = n.advertise<HXVolvo::initAutonomousMachine>("AutonomousMachine/initAutonomousMachine", 30);
environment_askClosestAutonomousMachine_pub = n.advertise<HXVolvo::askClosestAutonomousMachine>("environment/askClosestAutonomousMachine", 30);
environment_act_pub = n.advertise<HXVolvo::act>("environment/act", 30);
environment_selectLPorWL_pub = n.advertise<HXVolvo::selectLPorWL>("environment/selectLPorWL", 30);
self_selectNextTask_pub = n.advertise<HXVolvo::selectNextTask>("AutonomousMachine/selectNextTask", 30);
am0_askYourPositionAtTime_pub = n.advertise<HXVolvo::askYourPositionAtTime>("am0/askYourPositionAtTime", 30);
am1_askYourPositionAtTime_pub = n.advertise<HXVolvo::askYourPositionAtTime>("am1/askYourPositionAtTime", 30);
am0_myNextPosition_pub = n.advertise<HXVolvo::myNextPosition>("am0/myNextPosition", 30);
sender = _sender;
while(simulator_simulatorTopic_pub.getNumSubscribers() < 1 ||am1_myNextPosition_pub.getNumSubscribers() < 1 ||self_initAutonomousMachine_pub.getNumSubscribers() < 1 ||environment_askClosestAutonomousMachine_pub.getNumSubscribers() < 1 ||environment_act_pub.getNumSubscribers() < 1 ||environment_selectLPorWL_pub.getNumSubscribers() < 1 ||self_selectNextTask_pub.getNumSubscribers() < 1 ||am0_askYourPositionAtTime_pub.getNumSubscribers() < 1 ||am1_askYourPositionAtTime_pub.getNumSubscribers() < 1 ||am0_myNextPosition_pub.getNumSubscribers() < 1 );
id = ID;
currentPos[0] = initX;
currentPos[1] = initY;
originTask = originTaskInit;
destinationTask = destinationTaskInit;
pathIndex = pathIndexInit;
for(int i = 0;i < numOfMachine; i++){
otherAuthMachines[i] = - 1;}
;
batteryLevel = chargeAmount;
otherAuthMachines[id] = 0;
HXVolvo::initAutonomousMachine pubMsg25;
pubMsg25.sender=sender;
self_initAutonomousMachine_pub.publish(pubMsg25);
;

ros::spin();
}

void AutonomousMachine::initAutonomousMachineCallback(const HXVolvo::initAutonomousMachine & thisMsg){
sleep(1);
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
HXVolvo::askClosestAutonomousMachine pubMsg26;
pubMsg26.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg26);
;

}

void AutonomousMachine::closestAutonomousMachineCallback(const HXVolvo::closestAutonomousMachine & thisMsg){
#define autMach0 thisMsg.autMach0
#define autMach1 thisMsg.autMach1
sleep(1);
int pathNum = getPathNum(originTask,destinationTask);;
if (autMach0 && id != 0) {HXVolvo::askYourPositionAtTime pubMsg27;
pubMsg27.sender=sender;
am0_askYourPositionAtTime_pub.publish(pubMsg27);
;}
else {
if (id != 0) {otherAuthMachines[0] = 0;};};
if (autMach1 && id != 1) {HXVolvo::askYourPositionAtTime pubMsg28;
pubMsg28.sender=sender;
am1_askYourPositionAtTime_pub.publish(pubMsg28);
;}
else {
if (id != 1) {otherAuthMachines[1] = 0;};};
sleep(1);
if (! autMach0 && ! autMach1) {HXVolvo::simulatorTopic pubMsg29;
pubMsg29.robotId = id;
pubMsg29.pathNum = pathNum;
pubMsg29.pathIndex = pathIndex;
pubMsg29.sender=sender;
simulator_simulatorTopic_pub.publish(pubMsg29);
;
batteryLevel--;
currentPos[0] = pathCoordinate[pathNum][pathIndex][0];
currentPos[1] = pathCoordinate[pathNum][pathIndex][1];
pathIndex++;
HXVolvo::act pubMsg30;
pubMsg30.currX = currentPos[0];
pubMsg30.currY = currentPos[1];
pubMsg30.sender=sender;
environment_act_pub.publish(pubMsg30);
;
sleep(1);
if (batteryLevel <= 0) {;};
for(int i = 0;i < numOfMachine; i++){
otherAuthMachines[i] = - 1;}
;
bool isNotAtIntersection = true;;
if (currentPos[0] == 4 && currentPos[1] == 5 && destinationTask == 1 || destinationTask == 2) {HXVolvo::selectLPorWL pubMsg31;
pubMsg31.sender=sender;
environment_selectLPorWL_pub.publish(pubMsg31);
;}
else {
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
int newX = pathCoordinate[pathNum][pathIndex][0];;
int newY = pathCoordinate[pathNum][pathIndex][1];;
if (newX != - 1 && newY != - 1) {otherAuthMachines[id] = 0;
HXVolvo::askClosestAutonomousMachine pubMsg32;
pubMsg32.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg32);
;

;}
else {
if (destinationTask == 0) {timeForMoving = chargeAmount - batteryLevel * chargeBatteryPerUnit + comTime;};
HXVolvo::selectNextTask pubMsg33;
pubMsg33.sender=sender;
self_selectNextTask_pub.publish(pubMsg33);
;

;};

;};

;};

#undef autMach0
#undef autMach1
}

void AutonomousMachine::askYourPositionAtTimeCallback(const HXVolvo::askYourPositionAtTime & thisMsg){
sleep(1);
if (thisMsg.sender == am0) {HXVolvo::myNextPosition pubMsg34;
pubMsg34.nextX = currentPos[0];
pubMsg34.nextY = currentPos[1];
pubMsg34.sender=sender;
am0_myNextPosition_pub.publish(pubMsg34);
;}
else {
if (thisMsg.sender == am1) {HXVolvo::myNextPosition pubMsg35;
pubMsg35.nextX = currentPos[0];
pubMsg35.nextY = currentPos[1];
pubMsg35.sender=sender;
am1_myNextPosition_pub.publish(pubMsg35);
;};};

}

void AutonomousMachine::selectNextTaskCallback(const HXVolvo::selectNextTask & thisMsg){
originTask = destinationTask;
if (destinationTask == 0) {batteryLevel = chargeAmount;};
pathIndex = 0;
int taskIndex = getTaskIndex(destinationTask);;
switch(taskIndex){
case 0 : {
destinationTask = 3; break;; }
case 1 : {
destinationTask = 0; break;; }
case 2 : {
destinationTask = 1; break;; }
}
;
int pathNum = getPathNum(originTask,destinationTask);;
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
otherAuthMachines[id] = 0;
HXVolvo::askClosestAutonomousMachine pubMsg36;
pubMsg36.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg36);
;

}

void AutonomousMachine::myNextPositionCallback(const HXVolvo::myNextPosition & thisMsg){
#define nextX thisMsg.nextX
#define nextY thisMsg.nextY
int pathNum = getPathNum(originTask,destinationTask);;
int myNextX = pathCoordinate[pathNum][pathIndex][0];;
int myNextY = pathCoordinate[pathNum][pathIndex][1];;
if (currentPos[0] == nextX && currentPos[1] == nextY) {;};
int machineId;;
if (thisMsg.sender == am0) {machineId = 0;}
else {
if (thisMsg.sender == am1) {machineId = 1;};};
otherAuthMachines[machineId] = checkGivenPosition(myNextX,myNextY,nextX,nextY);
bool isWaiting = false;;
bool allHaulers = false;;
for(int i = 0;i < numOfMachine; i++){
if (otherAuthMachines[i] == - 1) {allHaulers = false;
break;;

;}
else {
allHaulers = true;};}
;
if (allHaulers) {for(int i = 0;i < numOfMachine; i++){
if (i != id) {if (otherAuthMachines[i] == 1) {isWaiting = true;
break;;

;};};}
;
batteryLevel--;
if (! isWaiting) {currentPos[0] = myNextX;
currentPos[1] = myNextY;
pathIndex++;

;};
HXVolvo::act pubMsg37;
pubMsg37.currX = currentPos[0];
pubMsg37.currY = currentPos[1];
pubMsg37.sender=sender;
environment_act_pub.publish(pubMsg37);
;
if (batteryLevel <= 0) {;};
for(int i = 0;i < numOfMachine; i++){
otherAuthMachines[i] = - 1;}
;
bool isNotAtIntersection = true;;
if (currentPos[0] == 4 && currentPos[1] == 5 && destinationTask == 1 || destinationTask == 2) {HXVolvo::selectLPorWL pubMsg38;
pubMsg38.sender=sender;
environment_selectLPorWL_pub.publish(pubMsg38);
;}
else {
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
int newX = pathCoordinate[pathNum][pathIndex][0];;
int newY = pathCoordinate[pathNum][pathIndex][1];;
if (newX != - 1 && newY != - 1) {otherAuthMachines[id] = 0;
HXVolvo::askClosestAutonomousMachine pubMsg39;
pubMsg39.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg39);
;

;}
else {
if (destinationTask == 0) {timeForMoving = chargeAmount - batteryLevel * chargeBatteryPerUnit + comTime;};
HXVolvo::selectNextTask pubMsg40;
pubMsg40.sender=sender;
self_selectNextTask_pub.publish(pubMsg40);
;

;};

;};

;};

#undef nextX
#undef nextY
}

void AutonomousMachine::reachLPDestinationCallback(const HXVolvo::reachLPDestination & thisMsg){
#define isLPBetter thisMsg.isLPBetter
destinationTask = (isLPBetter) ? (1) : (2);
int pathNum = (isLPBetter) ? (1) : (3);;
pathIndex = 5;
int timeForMoving = getTimeForMoving(originTask,destinationTask,pathIndex) + comTime;;
otherAuthMachines[id] = 0;
HXVolvo::askClosestAutonomousMachine pubMsg41;
pubMsg41.sender=sender;
environment_askClosestAutonomousMachine_pub.publish(pubMsg41);
;

#undef isLPBetter
}

int AutonomousMachine::checkGivenPosition(int x1,int y1,int x2,int y2){
if (x1 != x2 || y1 != y2) {return 0;}
else {
return 1;};

}

int AutonomousMachine::getTimeForMoving(int originTaskPar,int destinationTaskPar,int pathIndexPar){
int pathNum = getPathNum(originTaskPar,destinationTaskPar);;
return pathsTimes[pathNum][pathIndexPar];

}

int AutonomousMachine::getTaskIndex(int destinationTaskPar){
int taskIndex;;
switch(destinationTaskPar){
case 0 : {
taskIndex = 2; break;; }
case 1 : {
taskIndex = 0; break;; }
case 2 : {
taskIndex = 0; break;; }
case 3 : {
taskIndex = 1; break;; }
}
;
return taskIndex;

}

int AutonomousMachine::getPathNum(int originTaskPar,int destinationTaskPar){
return taskNumber[originTaskPar][destinationTaskPar];

}

