#include <HXVolvo/Environment.h>


/* the following variables are needed for using sender keyword */
std::string am0;
std::string am1;
int main(int argc, char** argv){
	ROS_INFO("Environment node started");
	ros::init(argc, argv, "Environment_node");
	ros::NodeHandle nh("~");
	std::string sender;
	 nh.getParam("sender", sender);
	 nh.getParam("am0", am0);
	 nh.getParam("am1", am1);
	int am0X;
	 nh.getParam("am0X", am0X);
	int am0Y;
	 nh.getParam("am0Y", am0Y);
	int am1X;
	 nh.getParam("am1X", am1X);
	int am1Y;
	 nh.getParam("am1Y", am1Y);
	Environment _environment(am0X, am0Y, am1X, am1Y, sender);
}


Environment::Environment(int am0X, int am0Y, int am1X, int am1Y, std::string _sender){
askClosestAutonomousMachine_sub = n.subscribe("Environment/askClosestAutonomousMachine", 30, &Environment::askClosestAutonomousMachineCallback, this);
selectLPorWL_sub = n.subscribe("Environment/selectLPorWL", 30, &Environment::selectLPorWLCallback, this);
act_sub = n.subscribe("Environment/act", 30, &Environment::actCallback, this);
am0_reachLPDestination_pub = n.advertise<HXVolvo::reachLPDestination>("am0/reachLPDestination", 30);
am1_closestAutonomousMachine_pub = n.advertise<HXVolvo::closestAutonomousMachine>("am1/closestAutonomousMachine", 30);
am1_reachLPDestination_pub = n.advertise<HXVolvo::reachLPDestination>("am1/reachLPDestination", 30);
am0_closestAutonomousMachine_pub = n.advertise<HXVolvo::closestAutonomousMachine>("am0/closestAutonomousMachine", 30);
sender = _sender;
while(am0_reachLPDestination_pub.getNumSubscribers() < 1 ||am1_closestAutonomousMachine_pub.getNumSubscribers() < 1 ||am1_reachLPDestination_pub.getNumSubscribers() < 1 ||am0_closestAutonomousMachine_pub.getNumSubscribers() < 1 );
amPositions[0][0] = am0X;
amPositions[0][1] = am0Y;
amPositions[1][0] = am1X;
amPositions[1][1] = am1Y;

ros::spin();
}

void Environment::askClosestAutonomousMachineCallback(const HXVolvo::askClosestAutonomousMachine & thisMsg){
int amID;;
if (thisMsg.sender == am0) {amID = 0;}
else {
if (thisMsg.sender == am1) {amID = 1;};};
bool cAM[2];;
cAM[amID] = false;
for(int i = 0;i < numOfMachine; i++){
if (i != amID) {cAM[i] = isAutonomousMachineCloseEnough(amPositions[amID][0],amPositions[amID][1],amPositions[i][0],amPositions[i][1]);};}
;
switch(amID){
case 0 : {
HXVolvo::closestAutonomousMachine pubMsg4;
pubMsg4.autMach0 = cAM[0];
pubMsg4.autMach1 = cAM[1];
pubMsg4.sender=sender;
am0_closestAutonomousMachine_pub.publish(pubMsg4);
; break;; }
case 1 : {
HXVolvo::closestAutonomousMachine pubMsg5;
pubMsg5.autMach0 = cAM[0];
pubMsg5.autMach1 = cAM[1];
pubMsg5.sender=sender;
am1_closestAutonomousMachine_pub.publish(pubMsg5);
; break;; }
}
;

}

void Environment::selectLPorWLCallback(const HXVolvo::selectLPorWL & thisMsg){
int queueLP = 0;;
int queueWL = 0;;
for(int i = 0;i < numOfMachine; i++){
if (amPositions[i][0] == 3 && amPositions[i][1] == 5 || amPositions[i][0] == 2 && amPositions[i][1] == 5) {queueLP++;};}
;
for(int i = 0;i < numOfMachine; i++){
if (amPositions[i][0] == 4 && amPositions[i][1] == 6 || amPositions[i][0] == 4 && amPositions[i][1] == 7 || amPositions[i][0] == 3 && amPositions[i][1] == 7 || amPositions[i][0] == 2 && amPositions[i][1] == 7 || amPositions[i][0] == 2 && amPositions[i][1] == 8) {queueWL++;};}
;
bool isLPBetter = queueLP <= queueWL;;
if (thisMsg.sender == am0) {HXVolvo::reachLPDestination pubMsg6;
pubMsg6.isLPBetter = isLPBetter;
pubMsg6.sender=sender;
am0_reachLPDestination_pub.publish(pubMsg6);
;}
else {
if (thisMsg.sender == am1) {HXVolvo::reachLPDestination pubMsg7;
pubMsg7.isLPBetter = isLPBetter;
pubMsg7.sender=sender;
am1_reachLPDestination_pub.publish(pubMsg7);
;};};

}

void Environment::actCallback(const HXVolvo::act & thisMsg){
#define currX thisMsg.currX
#define currY thisMsg.currY
int amID;;
if (thisMsg.sender == am0) {amID = 0;}
else {
if (thisMsg.sender == am1) {amID = 1;};};
amPositions[amID][0] = currX;
amPositions[amID][1] = currY;
if (currX < 0 || currX >= xBound || currY < 0 || currY >= yBound) {;};

#undef currX
#undef currY
}

bool Environment::isAutonomousMachineCloseEnough(int x0,int y0,int x1,int y1){
int distance = 0;;
int xDist;int yDist;;
if (x0 >= x1) {xDist = x0 - x1;}
else {
xDist = x1 - x0;};
if (y0 >= y1) {yDist = y0 - y1;}
else {
yDist = y1 - y0;};
distance = xDist + yDist;
if (distance <= distanceLimit) {return true;}
else {
return false;};

}

