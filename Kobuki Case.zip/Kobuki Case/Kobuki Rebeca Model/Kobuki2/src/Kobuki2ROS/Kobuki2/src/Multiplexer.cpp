#include <Kobuki2/Multiplexer.h>


/* the following variables are needed for using sender keyword */
std::string motor;
int main(int argc, char** argv){
	ROS_INFO("Multiplexer node started");
	ros::init(argc, argv, "Multiplexer_node");
	ros::NodeHandle nh("~");
	std::string sender;
	 nh.getParam("sender", sender);
	 nh.getParam("motor", motor);
	Multiplexer _multiplexer(sender);
}


Multiplexer::Multiplexer(std::string _sender){
safetyContollerActivated_sub = n.subscribe("Multiplexer/safetyContollerActivated", 30, &Multiplexer::safetyContollerActivatedCallback, this);
receiveCommandFromKeyboard_sub = n.subscribe("Multiplexer/receiveCommandFromKeyboard", 30, &Multiplexer::receiveCommandFromKeyboardCallback, this);
receiveCommandFromApp_sub = n.subscribe("Multiplexer/receiveCommandFromApp", 30, &Multiplexer::receiveCommandFromAppCallback, this);
receiveCommandFromNavigationStack_sub = n.subscribe("Multiplexer/receiveCommandFromNavigationStack", 30, &Multiplexer::receiveCommandFromNavigationStackCallback, this);
decide_sub = n.subscribe("Multiplexer/decide", 30, &Multiplexer::decideCallback, this);
motorCouldMove_sub = n.subscribe("Multiplexer/motorCouldMove", 30, &Multiplexer::motorCouldMoveCallback, this);
motorCouldnotMove_sub = n.subscribe("Multiplexer/motorCouldnotMove", 30, &Multiplexer::motorCouldnotMoveCallback, this);
motor_changeDirection_pub = n.advertise<Kobuki2::changeDirection>("motor/changeDirection", 30);
self_decide_pub = n.advertise<Kobuki2::decide>("Multiplexer/decide", 30);
sender = _sender;
while(motor_changeDirection_pub.getNumSubscribers() < 1 ||self_decide_pub.getNumSubscribers() < 1 );
;
Kobuki2::decide pubMsg34;
pubMsg34.sender=sender;
self_decide_pub.publish(pubMsg34);
;

ros::spin();
}

void Multiplexer::safetyContollerActivatedCallback(const Kobuki2::safetyContollerActivated & thisMsg){
safetyControllerCommanded = true;

}

void Multiplexer::receiveCommandFromKeyboardCallback(const Kobuki2::receiveCommandFromKeyboard & thisMsg){
#define kDirection thisMsg.kDirection
keyboardCommanded = true;
keyboardDirection = kDirection;

#undef kDirection
}

void Multiplexer::receiveCommandFromAppCallback(const Kobuki2::receiveCommandFromApp & thisMsg){
#define aDirection thisMsg.aDirection
androidAppCommanded = true;
androidAppDirection = aDirection;

#undef aDirection
}

void Multiplexer::receiveCommandFromNavigationStackCallback(const Kobuki2::receiveCommandFromNavigationStack & thisMsg){
#define nDirection thisMsg.nDirection
navigationCommanded = true;
navigationDirection = nDirection;

#undef nDirection
}

void Multiplexer::decideCallback(const Kobuki2::decide & thisMsg){
if (safetyControllerCommanded) {Kobuki2::changeDirection pubMsg35;
pubMsg35.d = 0;
pubMsg35.sender=sender;
motor_changeDirection_pub.publish(pubMsg35);
;
resetSafety();

;}
else {
if (keyboardCommanded) {Kobuki2::changeDirection pubMsg36;
pubMsg36.d = keyboardDirection;
pubMsg36.sender=sender;
motor_changeDirection_pub.publish(pubMsg36);
;
resetKeyboard();

;}
else {
if (androidAppCommanded) {Kobuki2::changeDirection pubMsg37;
pubMsg37.d = androidAppDirection;
pubMsg37.sender=sender;
motor_changeDirection_pub.publish(pubMsg37);
;
resetAndroid();

;}
else {
if (navigationCommanded) {Kobuki2::changeDirection pubMsg38;
pubMsg38.d = navigationDirection;
pubMsg38.sender=sender;
motor_changeDirection_pub.publish(pubMsg38);
;
resetNavigation();

;};};};};
Kobuki2::decide pubMsg39;
pubMsg39.sender=sender;
self_decide_pub.publish(pubMsg39);
;

}

void Multiplexer::motorCouldMoveCallback(const Kobuki2::motorCouldMove & thisMsg){
motorIsMoving = false;

}

void Multiplexer::motorCouldnotMoveCallback(const Kobuki2::motorCouldnotMove & thisMsg){
motorIsMoving = false;

}

bool Multiplexer::resetSafety(){
safetyControllerCommanded = false;
return true;

}

bool Multiplexer::resetKeyboard(){
keyboardCommanded = false;
keyboardDirection = 0;
return false;

}

bool Multiplexer::resetAndroid(){
androidAppCommanded = false;
androidAppDirection = 0;
return false;

}

bool Multiplexer::resetNavigation(){
navigationCommanded = false;
navigationDirection = 0;
return false;

}

bool Multiplexer::clear(){
safetyControllerCommanded = false;
keyboardCommanded = false;
androidAppCommanded = false;
motorIsMoving = false;
direction = 0;
return true;

}

