#include <Kobuki2/SafetyController.h>


/* the following variables are needed for using sender keyword */
std::string controller;
std::string motor;
int main(int argc, char** argv){
	ROS_INFO("SafetyController node started");
	ros::init(argc, argv, "SafetyController_node");
	ros::NodeHandle nh("~");
	std::string sender;
	 nh.getParam("sender", sender);
	 nh.getParam("controller", controller);
	 nh.getParam("motor", motor);
	int itsPeriod;
	 nh.getParam("itsPeriod", itsPeriod);
	SafetyController _safetycontroller(itsPeriod, sender);
}


SafetyController::SafetyController(int itsPeriod, std::string _sender){
bumperSensed_sub = n.subscribe("SafetyController/bumperSensed", 30, &SafetyController::bumperSensedCallback, this);
wheelDropperSensed_sub = n.subscribe("SafetyController/wheelDropperSensed", 30, &SafetyController::wheelDropperSensedCallback, this);
cliffSensed_sub = n.subscribe("SafetyController/cliffSensed", 30, &SafetyController::cliffSensedCallback, this);
wallIsVeryClose_sub = n.subscribe("SafetyController/wallIsVeryClose", 30, &SafetyController::wallIsVeryCloseCallback, this);
checkForSensors_sub = n.subscribe("SafetyController/checkForSensors", 30, &SafetyController::checkForSensorsCallback, this);
motor_turnAround_pub = n.advertise<Kobuki2::turnAround>("motor/turnAround", 30);
controller_safetyContollerActivated_pub = n.advertise<Kobuki2::safetyContollerActivated>("controller/safetyContollerActivated", 30);
self_checkForSensors_pub = n.advertise<Kobuki2::checkForSensors>("SafetyController/checkForSensors", 30);
sender = _sender;
while(motor_turnAround_pub.getNumSubscribers() < 1 ||controller_safetyContollerActivated_pub.getNumSubscribers() < 1 ||self_checkForSensors_pub.getNumSubscribers() < 1 );
bumperSensorActivated = false;
wheelDropperSensorActivated = false;
cliffSensorActivated = false;
period = itsPeriod;
Kobuki2::checkForSensors pubMsg25;
pubMsg25.sender=sender;
self_checkForSensors_pub.publish(pubMsg25);
;

ros::spin();
}

void SafetyController::bumperSensedCallback(const Kobuki2::bumperSensed & thisMsg){
bumperSensorActivated = true;

}

void SafetyController::wheelDropperSensedCallback(const Kobuki2::wheelDropperSensed & thisMsg){
wheelDropperSensorActivated = true;

}

void SafetyController::cliffSensedCallback(const Kobuki2::cliffSensed & thisMsg){
cliffSensorActivated = true;

}

void SafetyController::wallIsVeryCloseCallback(const Kobuki2::wallIsVeryClose & thisMsg){
wallClose = true;

}

void SafetyController::checkForSensorsCallback(const Kobuki2::checkForSensors & thisMsg){
if (bumperSensorActivated || wheelDropperSensorActivated || cliffSensorActivated) {Kobuki2::safetyContollerActivated pubMsg26;
pubMsg26.sender=sender;
controller_safetyContollerActivated_pub.publish(pubMsg26);
;};
bumperSensorActivated = false;
wheelDropperSensorActivated = false;
cliffSensorActivated = false;
if (wallClose) {Kobuki2::turnAround pubMsg27;
pubMsg27.sender=sender;
motor_turnAround_pub.publish(pubMsg27);
;
wallClose = false;

;};
checkForSensors();

}

