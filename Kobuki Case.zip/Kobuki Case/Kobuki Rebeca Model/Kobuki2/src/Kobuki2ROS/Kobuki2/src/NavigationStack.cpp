#include <Kobuki2/NavigationStack.h>


/* the following variables are needed for using sender keyword */
std::string controller;
int main(int argc, char** argv){
	ROS_INFO("NavigationStack node started");
	ros::init(argc, argv, "NavigationStack_node");
	ros::NodeHandle nh("~");
	std::string sender;
	 nh.getParam("sender", sender);
	 nh.getParam("controller", controller);
	int itsDelay;
	 nh.getParam("itsDelay", itsDelay);
	int itsPeriod;
	 nh.getParam("itsPeriod", itsPeriod);
	NavigationStack _navigationstack(itsDelay, itsPeriod, sender);
}


NavigationStack::NavigationStack(int itsDelay, int itsPeriod, std::string _sender){
sendVelocityCommands_sub = n.subscribe("NavigationStack/sendVelocityCommands", 30, &NavigationStack::sendVelocityCommandsCallback, this);
self_sendVelocityCommands_pub = n.advertise<Kobuki2::sendVelocityCommands>("NavigationStack/sendVelocityCommands", 30);
controller_receiveCommandFromNavigationStack_pub = n.advertise<Kobuki2::receiveCommandFromNavigationStack>("controller/receiveCommandFromNavigationStack", 30);
sender = _sender;
while(self_sendVelocityCommands_pub.getNumSubscribers() < 1 ||controller_receiveCommandFromNavigationStack_pub.getNumSubscribers() < 1 );
period = itsPeriod;
sleep = itsDelay;
Kobuki2::sendVelocityCommands pubMsg9;
pubMsg9.sender=sender;
self_sendVelocityCommands_pub.publish(pubMsg9);
;

ros::spin();
}

void NavigationStack::sendVelocityCommandsCallback(const Kobuki2::sendVelocityCommands & thisMsg){
int movementDirection = 1;;
Kobuki2::receiveCommandFromNavigationStack pubMsg10;
pubMsg10.nDirection = movementDirection;
pubMsg10.sender=sender;
controller_receiveCommandFromNavigationStack_pub.publish(pubMsg10);
;
Kobuki2::sendVelocityCommands pubMsg11;
pubMsg11.sender=sender;
self_sendVelocityCommands_pub.publish(pubMsg11);
;

}

