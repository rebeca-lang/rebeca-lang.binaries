#include <ros/ros.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/motorCouldMove.h>
#include <Kobuki2/bumperSensed.h>
#include <Kobuki2/wheelDropperSensed.h>
#include <Kobuki2/cliffSensed.h>
#include <Kobuki2/wallIsVeryClose.h>
#include <Kobuki2/checkForSensors.h>
#include <Kobuki2/safetyContollerActivated.h>
#include <Kobuki2/receiveCommandFromKeyboard.h>
#include <Kobuki2/receiveCommandFromApp.h>
#include <Kobuki2/receiveCommandFromNavigationStack.h>
#include <Kobuki2/decide.h>
#include <Kobuki2/motorCouldMove.h>
#include <Kobuki2/motorCouldnotMove.h>
#include <Kobuki2/changeDirection.h>
#include <Kobuki2/turnAround.h>
#include <Kobuki2/moveStepByStep.h>
#include <string>
#include <stdlib.h> // sleep function
#include <bitset>
#include <geometry_msgs/Twist.h> // for ROS movement commands 
typedef std::bitset<8> byte;

class Multiplexer{
public:
Multiplexer(std::string _sender);
void safetyContollerActivatedCallback(const Kobuki2::safetyContollerActivated & thisMsg);
void receiveCommandFromKeyboardCallback(const Kobuki2::receiveCommandFromKeyboard & thisMsg);
void receiveCommandFromAppCallback(const Kobuki2::receiveCommandFromApp & thisMsg);
void receiveCommandFromNavigationStackCallback(const Kobuki2::receiveCommandFromNavigationStack & thisMsg);
void decideCallback(const Kobuki2::decide & thisMsg);
void motorCouldMoveCallback(const Kobuki2::motorCouldMove & thisMsg);
void motorCouldnotMoveCallback(const Kobuki2::motorCouldnotMove & thisMsg);
private:
bool resetSafety();
bool resetKeyboard();
bool resetAndroid();
bool resetNavigation();
bool clear();
/*ROS Fields*/
ros::NodeHandle n;
ros::Publisher motor_changeDirection_pub;
ros::Publisher self_decide_pub;
ros::Subscriber safetyContollerActivated_sub;
ros::Subscriber receiveCommandFromKeyboard_sub;
ros::Subscriber receiveCommandFromApp_sub;
ros::Subscriber receiveCommandFromNavigationStack_sub;
ros::Subscriber decide_sub;
ros::Subscriber motorCouldMove_sub;
ros::Subscriber motorCouldnotMove_sub;
/* Reactive Class State Variables as Private Fields */
bool safetyControllerCommanded;;
bool keyboardCommanded;;
bool androidAppCommanded;;
bool navigationCommanded;;
bool motorIsMoving;;
int keyboardDirection;;
int androidAppDirection;;
int navigationDirection;;
int direction;;
std::string sender;
const double translationalVelocity = 0.2;;
const int movementStepTime = 5;;
const int leftBoundry = - 10;;
const int rightBoundry = 10;;
const int wallClosenessThreshold = 4;;
const int safetyControllerPeriod = 16;;
const double goalLocation = 8;;
const int cliffLocation = 4;;
const int keyboardPeriod = 45;;
const int keyboardToControllerTime = 3;;
const int androidPeriod = 45;;
const int androidToControllerTime = 5;;
const int navigationPeriod = 20;;
const int navigationToControllerTime = 1;;
const int bumperSensorPeriod = 40;;
const int wheelDropperSensorPeriod = 30;;
const int cliffSensorPeriod = 20;;
const int wallDetectorPeriod = 2;;
const int controllerPeriod = 5;;
};