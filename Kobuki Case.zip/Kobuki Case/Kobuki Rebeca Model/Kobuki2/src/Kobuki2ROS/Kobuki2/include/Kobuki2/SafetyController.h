#include <ros/ros.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/motorCouldMove.h>
#include <Kobuki2/bumperSensed.h>
#include <Kobuki2/wheelDropperSensed.h>
#include <Kobuki2/cliffSensed.h>
#include <Kobuki2/wallIsVeryClose.h>
#include <Kobuki2/checkForSensors.h>
#include <Kobuki2/safetyContollerActivated.h>
#include <Kobuki2/receiveCommandFromKeyboard.h>
#include <Kobuki2/receiveCommandFromApp.h>
#include <Kobuki2/receiveCommandFromNavigationStack.h>
#include <Kobuki2/decide.h>
#include <Kobuki2/motorCouldMove.h>
#include <Kobuki2/motorCouldnotMove.h>
#include <Kobuki2/changeDirection.h>
#include <Kobuki2/turnAround.h>
#include <Kobuki2/moveStepByStep.h>
#include <string>
#include <stdlib.h> // sleep function
#include <bitset>
#include <geometry_msgs/Twist.h> // for ROS movement commands 
typedef std::bitset<8> byte;

class SafetyController{
public:
SafetyController(int itsPeriod, std::string _sender);
void bumperSensedCallback(const Kobuki2::bumperSensed & thisMsg);
void wheelDropperSensedCallback(const Kobuki2::wheelDropperSensed & thisMsg);
void cliffSensedCallback(const Kobuki2::cliffSensed & thisMsg);
void wallIsVeryCloseCallback(const Kobuki2::wallIsVeryClose & thisMsg);
void checkForSensorsCallback(const Kobuki2::checkForSensors & thisMsg);
private:
/*ROS Fields*/
ros::NodeHandle n;
ros::Publisher motor_turnAround_pub;
ros::Publisher controller_safetyContollerActivated_pub;
ros::Publisher self_checkForSensors_pub;
ros::Subscriber bumperSensed_sub;
ros::Subscriber wheelDropperSensed_sub;
ros::Subscriber cliffSensed_sub;
ros::Subscriber wallIsVeryClose_sub;
ros::Subscriber checkForSensors_sub;
/* Reactive Class State Variables as Private Fields */
bool bumperSensorActivated;;
bool wheelDropperSensorActivated;;
bool cliffSensorActivated;;
bool wallClose;;
int period;;
std::string sender;
const double translationalVelocity = 0.2;;
const int movementStepTime = 5;;
const int leftBoundry = - 10;;
const int rightBoundry = 10;;
const int wallClosenessThreshold = 4;;
const int safetyControllerPeriod = 16;;
const double goalLocation = 8;;
const int cliffLocation = 4;;
const int keyboardPeriod = 45;;
const int keyboardToControllerTime = 3;;
const int androidPeriod = 45;;
const int androidToControllerTime = 5;;
const int navigationPeriod = 20;;
const int navigationToControllerTime = 1;;
const int bumperSensorPeriod = 40;;
const int wheelDropperSensorPeriod = 30;;
const int cliffSensorPeriod = 20;;
const int wallDetectorPeriod = 2;;
const int controllerPeriod = 5;;
};