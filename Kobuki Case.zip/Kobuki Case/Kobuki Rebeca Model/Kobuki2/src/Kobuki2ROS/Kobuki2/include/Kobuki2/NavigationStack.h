#include <ros/ros.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sendVelocityCommands.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/sense.h>
#include <Kobuki2/motorCouldMove.h>
#include <Kobuki2/bumperSensed.h>
#include <Kobuki2/wheelDropperSensed.h>
#include <Kobuki2/cliffSensed.h>
#include <Kobuki2/wallIsVeryClose.h>
#include <Kobuki2/checkForSensors.h>
#include <Kobuki2/safetyContollerActivated.h>
#include <Kobuki2/receiveCommandFromKeyboard.h>
#include <Kobuki2/receiveCommandFromApp.h>
#include <Kobuki2/receiveCommandFromNavigationStack.h>
#include <Kobuki2/decide.h>
#include <Kobuki2/motorCouldMove.h>
#include <Kobuki2/motorCouldnotMove.h>
#include <Kobuki2/changeDirection.h>
#include <Kobuki2/turnAround.h>
#include <Kobuki2/moveStepByStep.h>
#include <string>
#include <stdlib.h> // sleep function
#include <bitset>
#include <geometry_msgs/Twist.h> // for ROS movement commands 
typedef std::bitset<8> byte;

class NavigationStack{
public:
NavigationStack(int itsDelay, int itsPeriod, std::string _sender);
void sendVelocityCommandsCallback(const Kobuki2::sendVelocityCommands & thisMsg);
private:
/*ROS Fields*/
ros::NodeHandle n;
ros::Publisher self_sendVelocityCommands_pub;
ros::Publisher controller_receiveCommandFromNavigationStack_pub;
ros::Subscriber sendVelocityCommands_sub;
/* Reactive Class State Variables as Private Fields */
int delay;;
int period;;
std::string sender;
const double translationalVelocity = 0.2;;
const int movementStepTime = 5;;
const int leftBoundry = - 10;;
const int rightBoundry = 10;;
const int wallClosenessThreshold = 4;;
const int safetyControllerPeriod = 16;;
const double goalLocation = 8;;
const int cliffLocation = 4;;
const int keyboardPeriod = 45;;
const int keyboardToControllerTime = 3;;
const int androidPeriod = 45;;
const int androidToControllerTime = 5;;
const int navigationPeriod = 20;;
const int navigationToControllerTime = 1;;
const int bumperSensorPeriod = 40;;
const int wheelDropperSensorPeriod = 30;;
const int cliffSensorPeriod = 20;;
const int wallDetectorPeriod = 2;;
const int controllerPeriod = 5;;
};