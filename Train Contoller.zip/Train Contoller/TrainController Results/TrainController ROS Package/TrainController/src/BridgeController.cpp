#include <TrainController/BridgeController.h>

int main(int argc, char** argv){
        ROS_INFO("BridgeController node started");
        ros::init(argc, argv, "BridgeController_node");
        BridgeController bridgecontroller;
}


BridgeController::BridgeController(){
    Arrive_sub = n.subscribe("BridgeController/Arrive", 30, &BridgeController::ArriveCallback, this);
    Leave_sub = n.subscribe("BridgeController/Leave", 30, &BridgeController::LeaveCallback, this);
    YouMayPass_pub1 = n.advertise<std_msgs::Empty>("train1/YouMayPass", 30);
    YouMayPass_pub2 = n.advertise<std_msgs::Empty>("train2/YouMayPass", 30);
    
    while(YouMayPass_pub1.getNumSubscribers() <= 0 || YouMayPass_pub2.getNumSubscribers() <= 0);
    
     while(! ros::ok());
    signal1 = false;    /* red */
    signal2 = false;    /* red */
    isWaiting1 = false;
    isWaiting2 = false;
    
    ros::spin();
}

void BridgeController::ArriveCallback(const TrainController::Arrive & thisMsg){
    ROS_INFO( "controller noticed that %s arrived", thisMsg.sender.c_str());
    std_msgs::Empty emptyMsg;
    if (thisMsg.sender == "train1"){
        if (signal2 == false) {
            signal1 = true; /* green */
            YouMayPass_pub1.publish(emptyMsg);
        }
        else {
            isWaiting1 = true;
        }
    }
    else {
        if (signal1 == false){
            signal2 = true; /* green */
            YouMayPass_pub2.publish(emptyMsg);
        }
        else{
            isWaiting2 = true;
        }
    }
    ros::Rate loop_rate(1);
    loop_rate.sleep();
}

void BridgeController::LeaveCallback(const TrainController::Leave & thisMsg){
    ROS_INFO( "controller noticed that %s leaved", thisMsg.sender.c_str());
    std_msgs::Empty emptyMsg;
    if (thisMsg.sender == "train1") {
        signal1 = false;    /* red */
        if (isWaiting2){
            signal2 = true;
            YouMayPass_pub2.publish(emptyMsg);
            isWaiting2 = false;
        }
    } else {
        signal2 = false;    /* red */
        if (isWaiting1) {
            signal1 = true;
            YouMayPass_pub1.publish(emptyMsg);
            isWaiting1 = false;
        }
    }
    ros::Rate loop_rate(1);
    loop_rate.sleep();
    
}

