#include <TrainController/Train.h>

int main(int argc, char** argv){
	ros::init(argc, argv, "Train_node");
        ros::NodeHandle nh("~");
        std::string sender;
        nh.getParam("sender", sender);
        
        ROS_INFO("%s node started", sender.c_str());
	Train train(sender);
}


Train::Train(std::string _sender){
    sender = _sender;
    YouMayPass_sub = n.subscribe(sender + "/YouMayPass", 30, &Train::YouMayPassCallback, this);
    Passed_sub = n.subscribe(sender + "/Passed", 30, &Train::PassedCallback, this);
    ReachBridge_sub = n.subscribe(sender + "/ReachBridge", 30, &Train::ReachBridgeCallback, this);
    
    YouMayPass_pub = n.advertise<std_msgs::Empty>(sender + "/YouMayPass", 30);
    Passed_pub = n.advertise<std_msgs::Empty>(sender + "/Passed", 30);
    ReachBridge_pub = n.advertise<std_msgs::Empty>(sender + "/ReachBridge", 30);
    theController_Arrive_pub = n.advertise<TrainController::Arrive>("BridgeController/Arrive", 30);
    theController_Leave_pub = n.advertise<TrainController::Leave>("BridgeController/Leave", 30);
        
    while(theController_Arrive_pub.getNumSubscribers() <= 0 || theController_Leave_pub.getNumSubscribers() <= 0 );
     while(! ros::ok());
    
     std_msgs::Empty emptyMsg;
    Passed_pub.publish(emptyMsg);
    ros::Rate loop_rate(1);
    loop_rate.sleep();
    
    ros::spin();
}


void Train::YouMayPassCallback(const std_msgs::Empty & thisMsg){
    ROS_INFO(" %s received the permission to pass", sender.c_str());
    onTheBridge = true;
    std_msgs::Empty emptyMsg;
    Passed_pub.publish(emptyMsg);
    ros::Rate loop_rate(1);
    loop_rate.sleep();
}
void Train::PassedCallback(const std_msgs::Empty & thisMsg){
    ROS_INFO("%s passed the bridge", sender.c_str());
    onTheBridge = false;
    TrainController::Leave leaveMsg;
    leaveMsg.sender = sender;
    theController_Leave_pub.publish(leaveMsg);
    ros::Rate loop_rate(1);
    loop_rate.sleep();
    std_msgs::Empty emptyMsg;
    ReachBridge_pub.publish(emptyMsg);
    loop_rate.sleep();
}

void Train::ReachBridgeCallback(const std_msgs::Empty & thisMsg){
    ROS_INFO("%s reached to the bridge", sender.c_str());
    TrainController::Arrive arriveMsg;
    arriveMsg.sender = sender;
    theController_Arrive_pub.publish(arriveMsg);
    ros::Rate loop_rate(1);
    loop_rate.sleep();
}

