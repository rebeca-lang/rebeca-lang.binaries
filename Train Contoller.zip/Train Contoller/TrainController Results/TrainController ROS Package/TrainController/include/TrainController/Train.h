#include <ros/ros.h>
/* #include <TrainController/YouMayPass.h>
#include <TrainController/Passed.h>
#include <TrainController/ReachBridge.h> */
#include <TrainController/Arrive.h>
#include <TrainController/Leave.h>
#include <std_msgs/Empty.h>
#include <string>

class Train{
public:
Train(std::string sender);
void YouMayPassCallback(const std_msgs::Empty & thisMsg);
void PassedCallback(const std_msgs::Empty & thisMsg);
void ReachBridgeCallback(const std_msgs::Empty & thisMsg);
private:
/*ROS Fields*/
ros::NodeHandle n;
ros::Subscriber initial_sub;
ros::Subscriber YouMayPass_sub;
ros::Subscriber Passed_sub;
ros::Subscriber ReachBridge_sub;

ros::Publisher YouMayPass_pub;
ros::Publisher Passed_pub;
ros::Publisher ReachBridge_pub;
ros::Publisher theController_Arrive_pub;
ros::Publisher theController_Leave_pub;

/* Reactive Class State Variables as Private Fields */
bool onTheBridge;
std::string sender;
};