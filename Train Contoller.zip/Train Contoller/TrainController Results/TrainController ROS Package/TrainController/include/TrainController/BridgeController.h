#include <ros/ros.h>
#include <TrainController/Arrive.h>
#include <TrainController/Leave.h>
#include <std_msgs/Empty.h>
#include <string>

class BridgeController{
public:
BridgeController();
void ArriveCallback(const TrainController::Arrive & thisMsg);
void LeaveCallback(const TrainController::Leave & thisMsg);
private:
/*ROS Fields*/
ros::NodeHandle n;
ros::Subscriber Arrive_sub;
ros::Subscriber Leave_sub;
ros::Publisher YouMayPass_pub1;
ros::Publisher YouMayPass_pub2;

/* Reactive Class State Variables as Private Fields */
bool isWaiting1;
bool isWaiting2;
bool signal1;
bool signal2;
};