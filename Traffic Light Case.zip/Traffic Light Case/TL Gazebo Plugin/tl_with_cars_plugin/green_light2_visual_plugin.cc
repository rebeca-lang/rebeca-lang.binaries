 
 
#ifndef _GREEN_LIGHT2_PLUGIN_HH_
#define _GREEN_LIGHT2_PLUGIN_HH_

#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/transport/transport.hh>
#include <gazebo/msgs/msgs.hh>
#include "gazebo/common/Events.hh"


#include <boost/bind.hpp>
#include <gazebo/rendering/Visual.hh>
#include <gazebo/common/common.hh>
#include <thread>
#include "ros/ros.h"
#include "ros/callback_queue.h"
#include "ros/subscribe_options.h"
#include "std_msgs/Empty.h"



namespace gazebo
{
  /// \brief A plugin to control traffic lights
  class GreenLight2Plugin : public VisualPlugin
  {
    /// \brief Constructor
    public: GreenLight2Plugin() {}

    /// \brief The load function is called by Gazebo when the plugin is
    /// inserted into simulation
    /// \param[in] _model A pointer to the model that this plugin is
    /// attached to.
    /// \param[in] _sdf A pointer to the plugin's SDF element.
    public: virtual void Load(rendering::VisualPtr _parent, sdf::ElementPtr _sdf)
    {
        

      // Just output a message for now
      std::cerr << "\nThe Green Lights visual plugin is attached to visual[" <<
        _parent->GetName() << "]\n";
        
      this->model = _parent;
      this->updateConnection = event::Events::ConnectPreRender(boost::bind(&GreenLight2Plugin::OnUpdate, this));
    
        // Initialize ros, if it has not already bee initialized.
       if (!ros::isInitialized())
        {
        int argc = 0;
        char **argv = NULL;
        ros::init(argc, argv, "gt2_gazebo_client",
            ros::init_options::NoSigintHandler);
        } 

        // Create our ROS node. This acts in a similar manner to
        // the Gazebo node
        this->rosNode.reset(new ros::NodeHandle("gt2_gazebo_client"));  
      
        this->rosSub = this->rosNode->subscribe("/traffic_light2/green_LED/ON", 1000, &GreenLight2Plugin::TurnOnGreenLED, this);
        this->rosSub2 = this->rosNode->subscribe("/traffic_light2/green_LED/OFF", 1000, &GreenLight2Plugin::TurnOffGreenLED, this); 

        //Spin up the queue helper thread.
        this->rosQueueThread =
        std::thread(std::bind(&GreenLight2Plugin::QueueThread, this));
        
        this->updateConnection = event::Events::ConnectRender(
          boost::bind(&GreenLight2Plugin::OnUpdate, this));
    }

        
     // ros::spin();
    
    public: void OnUpdate(){
        ros::spinOnce();
    }
    
 
    public: void TurnOnGreenLED(const std_msgs::Empty &_msg)
    {
        common::Color c(0.0, 1.0, 0.0);
        this->model->SetAmbient(c);
        this->model->SetDiffuse(c);
    }
    
        public: void TurnOffGreenLED(const std_msgs::Empty &_msg)
    {
        common::Color c(0.0, 0.0, 0.0);
        this->model->SetAmbient(c);
        this->model->SetDiffuse(c);
    }
    
    /// \brief ROS helper function that processes messages
    private: void QueueThread()
    {
        static const double timeout = 0.01;
        while (this->rosNode->ok())
        {
            this->rosQueue.callAvailable(ros::WallDuration(timeout));
        }
    }  
    

    private: transport::NodePtr node;
    rendering::VisualPtr model;
    
    event::ConnectionPtr updateConnection;
    
    /// \brief A ROS subscriber
    private: ros::Subscriber rosSub; 
    
    private: ros::Subscriber rosSub2; 


    /// \brief A ROS callbackqueue that helps process messages
   private: ros::CallbackQueue rosQueue; 

    /// \brief A thread the keeps running the rosQueue
    private: std::thread rosQueueThread; 
    
    /// \brief A node use for ROS transport
    private: std::unique_ptr<ros::NodeHandle> rosNode; 
    


  };

  // Tell Gazebo about this plugin, so that Gazebo can call Load on this plugin.
  GZ_REGISTER_VISUAL_PLUGIN(GreenLight2Plugin)
}
#endif