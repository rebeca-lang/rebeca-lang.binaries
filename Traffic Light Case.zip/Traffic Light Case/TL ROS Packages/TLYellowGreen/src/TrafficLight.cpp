#include <TLYellowGreen/TrafficLight.h>

int main(int argc, char** argv){
    ros::init(argc, argv, "TrafficLight_node");
        
    /*get initial values from launch file */
    ros::NodeHandle nh("~");
    std::string myId;
    std::string toOtherId;
    nh.getParam("myId", myId);
    nh.getParam("toOtherId", toOtherId);
        
    ROS_INFO("TrafficLight %s node started", myId.c_str());
    TrafficLight trafficlight(myId, toOtherId);
}


TrafficLight::TrafficLight(std::string myId, std::string toOtherId){
    nodeName = "TrafficLight" + myId;
    std::string toOtherName = "TrafficLight" + toOtherId;
    RedtoGreen_sub = n.subscribe(nodeName + "/RedtoGreen", 30, &TrafficLight::RedtoGreenCallback, this);
    GreentoYellow_sub = n.subscribe(nodeName + "/GreentoYellow", 30, &TrafficLight::GreentoYellowCallback, this);
    YellowtoRed_sub = n.subscribe(nodeName + "/YellowtoRed", 30, &TrafficLight::YellowtoRedCallback, this);
    RedtoGreen_pub = n.advertise<std_msgs::Empty>(nodeName + "/RedtoGreen", 30);
    GreentoYellow_pub = n.advertise<std_msgs::Empty>(nodeName + "/GreentoYellow", 30);
    YellowtoRed_pub = n.advertise<std_msgs::Empty>(nodeName + "/YellowtoRed", 30);
    toOtherRedtoGreen_pub = n.advertise<std_msgs::Empty>(toOtherName + "/RedtoGreen", 30);
    
    /* publishers to the topics related to gazebo simulation */
    gazebo_red_on_pub = n.advertise<std_msgs::Empty>("/traffic_light1/red_LED/ON", 30);
    gazebo_green_on_pub = n.advertise<std_msgs::Empty>("/traffic_light1/green_LED/ON", 30);
    gazebo_yellow_on_pub = n.advertise<std_msgs::Empty>("/traffic_light1/yellow_LED/ON", 30);
    gazebo_red_off_pub = n.advertise<std_msgs::Empty>("/traffic_light1/red_LED/OFF", 30);
    gazebo_green_off_pub = n.advertise<std_msgs::Empty>("/traffic_light1/green_LED/OFF", 30);
    gazebo_yellow_off_pub = n.advertise<std_msgs::Empty>("/traffic_light1/yellow_LED/OFF", 30);
    if(myId == "2"){
        gazebo_red_on_pub = n.advertise<std_msgs::Empty>("/traffic_light2/red_LED/ON", 30);
        gazebo_green_on_pub = n.advertise<std_msgs::Empty>("/traffic_light2/green_LED/ON", 30);
        gazebo_yellow_on_pub = n.advertise<std_msgs::Empty>("/traffic_light2/yellow_LED/ON", 30);
        gazebo_red_off_pub = n.advertise<std_msgs::Empty>("/traffic_light2/red_LED/OFF", 30);
        gazebo_green_off_pub = n.advertise<std_msgs::Empty>("/traffic_light2/green_LED/OFF", 30);
        gazebo_yellow_off_pub = n.advertise<std_msgs::Empty>("/traffic_light2/yellow_LED/OFF", 30);
    }
    
    
    std_msgs::Empty emptyMsg;
    Color = 0;
    gazebo_red_on_pub.publish(emptyMsg);
    ROS_INFO("%s %s", nodeName.c_str(), "is Red");
    if(myId == "1"){
        RedtoGreen_pub.publish(emptyMsg);
    }
    
    while(RedtoGreen_pub.getNumSubscribers() <= 0 || GreentoYellow_pub.getNumSubscribers() <= 0 ||
        YellowtoRed_pub.getNumSubscribers() <=0 || toOtherRedtoGreen_pub.getNumSubscribers() <= 0);
    
    ros::spin();
}

void TrafficLight::RedtoGreenCallback(const std_msgs::Empty & thisMsg){
    std_msgs::Empty emptyMsg;
    gazebo_red_off_pub.publish(emptyMsg);
    Color = 1;
    gazebo_green_on_pub.publish(emptyMsg);
    ROS_INFO("%s %s", nodeName.c_str(), "is Green");
    GreentoYellow_pub.publish(emptyMsg);
    
    ros::Rate loop_rate(1);
    loop_rate.sleep();
}

void TrafficLight::GreentoYellowCallback(const std_msgs::Empty & thisMsg){
    std_msgs::Empty emptyMsg;
    gazebo_green_off_pub.publish(emptyMsg);
    Color = 2;
    gazebo_yellow_on_pub.publish(emptyMsg);
    ROS_INFO("%s %s", nodeName.c_str(), "is Yellow");
    YellowtoRed_pub.publish(emptyMsg);
    
    toOtherRedtoGreen_pub.publish(emptyMsg);
    
    ros::Rate loop_rate(1);
    loop_rate.sleep();
}

void TrafficLight::YellowtoRedCallback(const std_msgs::Empty & thisMsg){
    std_msgs::Empty emptyMsg;
    gazebo_yellow_off_pub.publish(emptyMsg);
    Color = 0;
    gazebo_red_on_pub.publish(emptyMsg);
    ROS_INFO("%s %s", nodeName.c_str(), "is Red");
    
    ros::Rate loop_rate(1);
    loop_rate.sleep();
}

