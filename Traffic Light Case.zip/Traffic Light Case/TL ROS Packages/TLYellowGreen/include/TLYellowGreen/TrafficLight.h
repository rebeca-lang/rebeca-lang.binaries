#include <ros/ros.h>
/* #include <TLYellowGreen/RedtoGreenMsg.h>
#include <TLYellowGreen/GreentoYellowMsg.h>
#include <TLYellowGreen/YellowtoRedMsg.h> */
#include <std_msgs/Empty.h>
#include <string>

class TrafficLight{
public:
    TrafficLight(std::string myId, std::string toOtherId);
    void RedtoGreenCallback(const std_msgs::Empty & thisMsg);
    void GreentoYellowCallback(const std_msgs::Empty & thisMsg);
    void YellowtoRedCallback(const std_msgs::Empty & thisMsg);
    
private:
    /*ROS Fields*/
    ros::NodeHandle n;
    ros::Subscriber RedtoGreen_sub;
    ros::Subscriber GreentoYellow_sub;
    ros::Subscriber YellowtoRed_sub;
    ros::Publisher RedtoGreen_pub;
    ros::Publisher GreentoYellow_pub;
    ros::Publisher YellowtoRed_pub;
    ros::Publisher toOtherRedtoGreen_pub;
    
    ros::Publisher gazebo_red_on_pub;
    ros::Publisher gazebo_green_on_pub;
    ros::Publisher gazebo_yellow_on_pub;
    ros::Publisher gazebo_red_off_pub;
    ros::Publisher gazebo_green_off_pub;
    ros::Publisher gazebo_yellow_off_pub;
    /* Reactive Class State Variables as Private Fields */
    int Color;
    std::string nodeName;
};